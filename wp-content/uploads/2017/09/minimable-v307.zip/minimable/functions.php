<?php
	/**
	 * Starkers functions and definitions
	 *
	 * For more information on hooks, actions, and filters, see http://codex.wordpress.org/Plugin_API.
	 *
 	 * @package 	WordPress
 	 * @subpackage 	Starkers
 	 * @since 		Starkers 4.0
	 */

	/* ========================================================================================================================

	Required external files

	======================================================================================================================== */
	add_action( 'admin_enqueue_scripts', 'fw_admin_enqueuer' );
	function fw_admin_enqueuer( $hook ) {

	    if( is_admin() ) {
	        wp_enqueue_script( 'jquery-ui', 'http://code.jquery.com/ui/1.11.4/jquery-ui.js');
	        wp_enqueue_script( 'farbtastic' );
					wp_enqueue_media();
					wp_enqueue_script('thickbox');


					wp_register_script( 'new-uploader', get_template_directory_uri().'/admin/js/new-uploader.js', array( 'jquery' ),null);
					wp_enqueue_script( 'new-uploader' );
	        wp_register_script( 'metaboxes', get_template_directory_uri().'/admin/js/metaboxes.js', array( 'jquery' ),null);
	        wp_enqueue_script( 'metaboxes' );
	        wp_enqueue_script( 'my-theme-options', get_template_directory_uri() . '/admin/js/theme-options.js');
	   		wp_enqueue_style( 'farbtastic' );
	   		wp_enqueue_style('thickbox');
	    }
	}

	require_once ('admin/required-plugins/plugins.php');
	require_once ('admin/theme-options.php');
	require_once ('admin/premium.php');
	require_once( 'external/starkers-utilities.php' );
	require_once( 'admin/metaboxes.php' );
	require_once('admin/tinymce-shortcodes.php');
	include("admin/update_notifier.php");


	/* ========================================================================================================================

	Theme specific settings

	Uncomment register_nav_menus to enable a single menu with the title of "Primary Navigation" in your theme

	======================================================================================================================== */

	require_once( 'include/image-size.php' );

	register_nav_menus(array('primary' => 'Primary Navigation'));

	/* ========================================================================================================================

	Actions and Filters

	======================================================================================================================== */

	add_action( 'wp_enqueue_scripts', 'minimable_script_enqueuer' );

	/* ========================================================================================================================

	Scripts and styles

	======================================================================================================================== */


	function minimable_script_enqueuer() {

		if( !is_admin()){
			wp_deregister_script('jquery');
			wp_register_script('jquery', ("//code.jquery.com/jquery-1.11.0.min.js"), false, null, true);
			wp_enqueue_script('jquery');
			wp_register_script('jquery-migrate', ("//code.jquery.com/jquery-migrate-1.2.1.min.js"), false, null);
			wp_enqueue_script('jquery-migrate');
		}
		wp_register_script( 'html5', get_template_directory_uri().'/js/html5.js', array( 'jquery' ),null);
		wp_enqueue_script( 'html5' );
		wp_register_script( 'bootstrap-js', get_template_directory_uri().'/js/bootstrap.min.js', array( 'jquery' ),null,true );
		wp_enqueue_script( 'bootstrap-js' );
		wp_register_script( 'swipebox-js', get_template_directory_uri().'/js/jquery.swipebox.min.js', array( 'jquery' ),null,true );
		wp_enqueue_script( 'swipebox-js' );
		if (is_page_template('main-template.php')) {

			wp_register_script( 'plugins', get_template_directory_uri().'/js/plugins.js', array( 'jquery' ),null,true );
			wp_enqueue_script( 'plugins' );
			wp_register_script( 'site', get_template_directory_uri().'/js/site.js', array( 'jquery' ),null,true );
			wp_enqueue_script( 'site' );
			if (get_option('fw_onoff_scrollorama')) {
				wp_register_script( 'scrollorama', get_template_directory_uri().'/js/jquery.superscrollorama.js', array( 'jquery' ),null,true );
				wp_enqueue_script( 'scrollorama' );
				wp_register_script( 'scrolling-effect', get_template_directory_uri().'/js/scrolling-effect.js', array( 'jquery' ),null,true );
				wp_enqueue_script( 'scrolling-effect' );
			}
			if (get_option('fw_onoff_animation_title')) {
				wp_register_script( 'title-animation', get_template_directory_uri().'/js/title-animation.js', array( 'jquery' ),null,true );
				wp_enqueue_script( 'title-animation' );
			}
		}
		if (get_option('fw_onoff_custom_js')) {
			wp_register_script( 'custom-js', get_template_directory_uri().'/js/custom.js', array( 'jquery' ),null,true );
			wp_enqueue_script( 'custom-js' );
    }

		wp_register_style( 'open-sans', 'http://fonts.googleapis.com/css?family=Open+Sans:400,300', '', '', 'screen' );
    wp_enqueue_style( 'open-sans' );
    wp_register_style( 'lib', get_stylesheet_directory_uri().'/lib.css', '', null, 'screen' );
		wp_enqueue_style( 'lib' );
		wp_register_style( 'screen', get_stylesheet_directory_uri().'/style.css', '', null, 'screen' );
    wp_enqueue_style( 'screen' );

		if (get_option('fw_onoff_custom_css')) {
			wp_register_style( 'custom-style', get_stylesheet_directory_uri().'/custom.css', '', null, 'screen' );
	    wp_enqueue_style( 'custom-style' );
		}

	}
	require_once( 'include/style.php' );

	function fw_script() {
		wp_reset_query(); ?>

		<?php if ( !is_page_template('main-template.php')) {
			include('include/no-single-page-scripts.php');
	 	} else {
	 		include('include/single-page-scripts.php');
	 	?>
		<?php } ?>
	<?php }
	add_action('wp_footer', 'fw_script',100);
	/* ========================================================================================================================

	Custom Post Type

	======================================================================================================================== */

	include('include/custom-post-type.php');


	/* ========================================================================================================================

	Shortcode

	======================================================================================================================== */

	// Elements Shortcodes
	include('include/elements-shortcode.php');

	/* ========================================================================================================================

	Other functions

	======================================================================================================================== */
	function the_slug() {
    $post_data = get_page($page->ID, ARRAY_A);
    $slug = $post_data['post_name'];
    return $slug;
	}
	function the_fw_title() {
		$post_data = get_post($post->ID, ARRAY_A);
  	$title = $post_data['post_title'];
		$chars = array("[color]","[/color]","<span>","</span>","<br/>","<br>");
		$substitute = array("");
		$unwanted_array = array(    'Š'=>'S', 'š'=>'s', 'Ž'=>'Z', 'ž'=>'z', 'À'=>'A', 'Á'=>'A', 'Â'=>'A', 'Ã'=>'A', 'Ä'=>'A', 'Å'=>'A', 'Æ'=>'A', 'Ç'=>'C', 'È'=>'E', 'É'=>'E',
                            'Ê'=>'E', 'Ë'=>'E', 'Ì'=>'I', 'Í'=>'I', 'Î'=>'I', 'Ï'=>'I', 'Ñ'=>'N', 'Ò'=>'O', 'Ó'=>'O', 'Ô'=>'O', 'Õ'=>'O', 'Ö'=>'O', 'Ø'=>'O', 'Ù'=>'U',
                            'Ú'=>'U', 'Û'=>'U', 'Ü'=>'U', 'Ý'=>'Y', 'Þ'=>'B', 'ß'=>'Ss', 'à'=>'a', 'á'=>'a', 'â'=>'a', 'ã'=>'a', 'ä'=>'a', 'å'=>'a', 'æ'=>'a', 'ç'=>'c',
                            'è'=>'e', 'é'=>'e', 'ê'=>'e', 'ë'=>'e', 'ì'=>'i', 'í'=>'i', 'î'=>'i', 'ï'=>'i', 'ð'=>'o', 'ñ'=>'n', 'ò'=>'o', 'ó'=>'o', 'ô'=>'o', 'õ'=>'o',
                            'ö'=>'o', 'ø'=>'o', 'ù'=>'u', 'ú'=>'u', 'û'=>'u', 'ý'=>'y', 'ý'=>'y', 'þ'=>'b', 'ÿ'=>'y','Ğ'=>'G', 'İ'=>'I', 'Ş'=>'S', 'ğ'=>'g', 'ı'=>'i', 'ş'=>'s', 'ü'=>'u',
                            'ă'=>'a', 'Ă'=>'A', 'ș'=>'s', 'Ș'=>'S', 'ț'=>'t', 'Ț'=>'T'  );
		$anchor = strtr( $title, $unwanted_array );
		$anchor = str_replace($chars,$substitute,$anchor);
		$anchor = str_replace(" ","-",$anchor);
		$anchor = preg_replace('/[^A-Za-z0-9\-]/', '', $anchor); // Removes special chars.
		$anchor = strtolower($anchor);
    return $anchor;
}
?>