<script src="<?php bloginfo('template_url') ?>/js/stickyfooter.js"></script>
<script type="text/javascript">
	$('.top-nav a').each(function() {
		var _href = $(this).parent().not('.custom-link').children().attr("href");
		$(this).parent().not('.custom-link').children().attr("href", '<?php bloginfo('wpurl')?>/' + _href);
	});
	$('#mini-link').attr("href", '<?php bloginfo('wpurl')?>/');

	$(".swipebox, .gallery-icon a").swipebox( {
    hideBarsDelay : 0,
    useSVG : false
  });
  $("div.gallery a img").each(function() {
    var $this = jQuery(this);
    $this.parent().attr('title', $this.attr('alt'));
  });

  $('.home-link').removeClass('active');
	$('header').removeClass('home-top');
	$('header').addClass('blog-menu');
</script>