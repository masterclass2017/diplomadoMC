<?php
add_action( 'init', 'create_post_type' );

function create_post_type() {
	register_post_type( 'team',
		array(
			'labels' => array(
				'name' => __( 'Team' ),
				'singular_name' => __( 'Team Member' ),
				'add_new' => __( 'Add New' ),
				'add_new_item' => __( 'Add New Member' ),
				'edit' => __( 'Edit' ),
				'edit_item' => __( 'Edit Member' ),
				'new_item' => __( 'New Member' ),
				),
			'public' => true,
			'supports' => array( 'title', 'editor','thumbnail' )
			)

		);
	register_post_type( 'portfolio',
		array(
			'labels' => array(
				'name' => __( 'Portfolio' ),
				'singular_name' => __( 'Work ' ),
				'add_new' => __( 'Add New' ),
				'add_new_item' => __( 'Add New Work' ),
				'edit' => __( 'Edit' ),
				'edit_item' => __( 'Edit Work' ),
				'new_item' => __( 'New Work' ),
				),
			'public' => true,
			'supports' => array( 'title', 'editor','thumbnail' )
			)
		);
}
?>