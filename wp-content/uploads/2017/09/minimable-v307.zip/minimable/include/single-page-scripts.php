<script type="text/javascript">
	var speed = <?php echo (get_option('fw_speed') ? get_option('fw_speed') : 3000) ?>;
	var bgPreload = '<?php echo (get_option('fw_bg_preloader') ? get_option('fw_bg_preloader') : '#ffffff') ?>';
	var colorPreload = '<?php echo (get_option('fw_color_preloader') ? get_option('fw_color_preloader') : '#000') ?>';
	var heightPreload = '<?php echo (get_option('fw_preloader_bar_height') ? get_option('fw_preloader_bar_height') : '2') ?>';
	var topOffset;
	$(document).ready(function() {
    // Optimalisation: Store the references outside the event handler:
    var $window = $(window);
    topOffset = 100;

    function checkWidth() {
        var windowsize = $window.width();
        if (windowsize > 978) {
            topOffset = <?php echo (get_option('fw_nav_height') ? get_option('fw_nav_height') : 40) ?>;
        }
    }
    // Execute on load
    checkWidth();
    // Bind event listener
    $(window).bind("load resize", function() {
    	checkWidth;
    });
	});
</script>
<?php if (get_post_meta($post->ID, 'fw_enable_particles', true)) { ?>
<script>
var particlesOn = 1;
</script>
<?php } ?>