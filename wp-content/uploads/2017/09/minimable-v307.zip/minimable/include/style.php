<?php
function fw_css() {
		global $options;
		foreach ($options as $value) {
			if ((isset($value['id'])) && (isset($value['std']))) {
				if (FALSE === get_option( $value['id'])) { ${$value['id']} = $value['std']; } else { ${$value['id']} = get_option( $value['id'] ); }
			}
		}
		?>
		<style>
			.color, h1 > span, h2 > span, .description-text a, .description-text a:hover, ul.social li a span, .email-link:hover { color:<?php echo $fw_main_color ?>!important;}
			.circle-menu, .nav-tabs li a, #portfolio a.link-portfolio, input[type="submit"], .sc-btn {background:<?php echo $fw_main_color ?>;}
			.sc-btn:hover {background-color: #000;}
			.page-template-main-template .section-page {padding:0;}
			.page-template-main-template-php .section-page .container {padding:<?php echo $fw_nav_height +40 ?>px 0;}
			.page-template-main-template-php .home-section .container {padding:<?php echo $fw_nav_height +40 ?>px 20px;}
			.navbar { line-height:<?php echo $fw_nav_height ?>px;}
			.sub-menu {top:<?php echo $fw_nav_height +20?>px;}
			.navbar .nav > li:hover > .sub-menu {top:<?php echo $fw_nav_height +1?>px;}
			.navbar .collapse #nav-menu,#mini-logo a,.cart-contents,.cart-contents span{ height:<?php echo $fw_nav_height ?>px;}
			#mini-logo img { height:<?php echo $fw_logo_height ?>px;}
			.navbar .nav > li > a {line-height: <?php echo $fw_nav_height ?>px;}
			<?php if (!get_option('fw_onoff_animation_title')) { ?>
			.big-title {display:block;}
			<?php } ?>
			<?php if (get_option('fw_preloader_bar_width')) {?>
			#qLoverlay .queryloader__overlay__bar {
				max-width: <?php echo (get_option('fw_preloader_bar_width') ? get_option('fw_preloader_bar_width') : '100') ?>%!important;
				left: 50%!important;
				margin-left: -<?php echo (get_option('fw_preloader_bar_width') ? get_option('fw_preloader_bar_width') / 2 : '100') ?>%!important;
			}
			<?php } ?>
			#qLoverlay .queryloader__overlay__percentage {
				font-size: 20px!important;
				font-weight: 300!important;
			}
			#qLoverlay .queryloader__overlay__percentage:before {
				content: "<?php echo $fw_preloader_text ?>";
				margin-right: 10px;
			}
		</style>
		<?php
	}
	add_action('wp_head', 'fw_css');
?>