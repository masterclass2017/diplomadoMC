<?php

// Single item

$portfolio_fields = array(
    array(
        'label'=> 'Link',
        'desc'  => 'Link for the portfolio work',
        'id'    => $prefix.'link_portfolio',
        'type'  => 'text'
    )
);
?>