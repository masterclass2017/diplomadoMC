<?php
$particles_fields = array(

	array(
		'label' => 'Activate Particles',
		'desc' => 'Activate particles background. You can use it only for one section. In the premium version you can customize the particles (dots and lines color, speed)',
		'id' => $prefix.'enable_particles',
		'type' => 'checkbox',
		'std'  => ''
	)
);

$link_field = array (

	array(
		'label' => 'Page link for the menu',
		'desc' => 'This is the link you have to add in the menu',
		'id' => $prefix.'page_link',
		'type' => 'label',
		'std'  => ""
	),
	array(
		'label' => 'Page link alternative',
		'desc' => "If you don't like the page link or it has some special chars, you can write yours without space and any type of special chars, like this: the-anchor (without the '#' character). Then in the menu you need to write #the-anchor ",
		'id' => $prefix.'page_link_alternative',
		'type' => 'text',
		'std'  => ""
	)
);
?>