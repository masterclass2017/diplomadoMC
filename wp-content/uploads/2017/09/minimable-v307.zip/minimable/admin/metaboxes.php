<?php
/**
 *	Refactory metaboxes for Minimable
 *
 *	@ver: 0.1
 */

require_once( 'fw_meta_box.php' );

global $minimable_options;

$prefix = 'fw_';
$themename = 'Minimable';

$homeBubbles="$('#home_link')";

require_once('metaboxes/metaboxes_home.php');
require_once('metaboxes/metaboxes_contact.php');
require_once('metaboxes/metaboxes_staff.php');
require_once('metaboxes/metaboxes_common.php');
require_once('metaboxes/metaboxes_portfolio.php');
require_once('metaboxes/metaboxes_external_page.php');


$home_metaboxes_var = new fw_meta_box( 'bubbles_metaboxes', 'Bubbles Section Settings', 'page', 'normal', 'high' );
$contact_metaboxes_var = new fw_meta_box( 'contact_metaboxes', 'Contact Section Settings', 'page', 'normal', 'high' );
$staff_content_var = new fw_meta_box( 'staff_content', 'Staff content', 'page', 'normal', 'high' );
$link_page_var = new fw_meta_box( 'link_page', 'Page link for the menu', 'page', 'normal', 'high' );
$social_link_staff_var = new fw_meta_box( 'social_link', 'Social link', 'team', 'normal', 'high' );
$portfolio_item_settings = new fw_meta_box( 'link_portfolio', 'Item settings', 'portfolio', 'normal', 'high' );
$customization_external_page_var = new fw_meta_box( 'custom_external_page', 'Page Settings', 'page', 'normal', 'high' );
$particles_box_var = new fw_meta_box( 'particles_section', 'Add particles to this section', 'page', 'normal', 'high' );

$home_metaboxes_var->add_fields( $home_metaboxes );
$contact_metaboxes_var->add_fields( $contact_metaboxes );
$staff_content_var->add_fields( $staff_fields);
$link_page_var->add_fields( $link_field);
$social_link_staff_var->add_fields( $social_links);
$portfolio_item_settings->add_fields( $portfolio_fields);
$customization_external_page_var->add_fields( $external_page_fields );
$particles_box_var->add_fields( $particles_fields );

function fw_customize_meta_boxes() {
    /* Removes meta boxes from Posts */
    remove_meta_box('postcustom','post','normal');
    /* Removes meta boxes from pages */
    remove_meta_box('postcustom','page','normal');
    remove_meta_box('trackbacksdiv','page','normal');
    remove_meta_box('commentstatusdiv','page','normal');
    remove_meta_box('commentsdiv','page','normal');
  }
  add_action('admin_init','fw_customize_meta_boxes');

?>