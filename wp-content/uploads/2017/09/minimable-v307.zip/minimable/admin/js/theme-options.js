jQuery(document).ready(function($) {

	$('.settings-btn .btn a').click(function(e) {
		$('.tab-pane').hide();
   		$(this.hash).show();
   		$('.settings-btn .btn').removeClass('active');
   		$(this).parent().addClass('active');
   		e.preventDefault();
	});
});

