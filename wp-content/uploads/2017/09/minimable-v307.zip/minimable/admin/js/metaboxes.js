jQuery(document).ready(function($) {
	$('.settings-btn-mbox .btn-mbox a').click(function(e) {
		$(this).parent().parent().parent().find('.tab-pane').hide();
 		$(this.hash).show();
 		$(this).parent().parent().find('.btn-mbox').removeClass('active');
 		$(this).parent().addClass('active');
 		e.preventDefault();
	});
	var $template_select = jQuery('select#page_template'),
		$template_box = jQuery('#normal-sortables');

	$template_select.change(function() {
		var this_value = jQuery(this).val();
		$('#bubbles_metaboxes').css('display','none');
		$('#staff_content').css('display','none');
		$('#contact_metaboxes').css('display','none');
		$('#postdivrich').css('height','0');
		$('#postdivrich').css('visibility','hidden');
		$('#link_page').css('display','none');
		$('#custom_external_page').css('display','none');
		$('#particles_section').css('display','none');
		$('.settings-btn-mbox .btn-mbox a').parent().removeClass('active');
		$('.settings-btn-mbox .btn-mbox:first-child a').parent().addClass('active');
		$('.tab-pane').hide();
		$('.group-field .tab-pane:first-child').show();
		switch ( this_value ) {
			case 'default':
				$('#postdivrich').css('height','auto');
				$('#postdivrich').css('visibility','visible');
				$('#contact_information').css('display','none');
				$('#link_page').css('display','block');
				$('#custom_external_page').css('display','block');
				break;
			case 'templates/template-home.php':
				$('#bubbles_metaboxes').css('display','block');
				$('#link_page').css('display','block');
				$('#particles_section').css('display','block');
				break;
			case 'templates/template-staff.php':
				$('#staff_content').css('display','block');
				$('#postdivrich').css('height','auto');
				$('#postdivrich').css('visibility','visible');
				$('#link_page').css('display','block');
				$('#particles_section').css('display','block');
				break;
			case 'templates/template-contact.php':
				$('#contact_metaboxes').css('display','block');
				$('#link_page').css('display','block');
				$('#particles_section').css('display','block');
				break;
			case 'templates/template-gallery.php':
				$('#postdivrich').css('height','auto');
				$('#postdivrich').css('visibility','visible');
				$('#link_page').css('display','block');
				$('#particles_section').css('display','block');
				break;
			case 'templates/template-portfolio.php':
				$('#link_page').css('display','block');
				$('#particles_section').css('display','block');
				break;
			case 'templates/template-fullwidth.php':
				$('#postdivrich').css('height','auto');
				$('#postdivrich').css('visibility','visible');
				$('#link_page').css('display','block');
				$('#particles_section').css('display','block');
				break;
			case 'templates/template-page-fullwidth.php':
				$('#postdivrich').css('height','auto');
				$('#postdivrich').css('visibility','visible');
				$('#custom_section').css('display','none');
				$('#link_page').css('display','none');
				$('#custom_external_page').css('display','block');
		}
	});

	$template_select.trigger('change');
});