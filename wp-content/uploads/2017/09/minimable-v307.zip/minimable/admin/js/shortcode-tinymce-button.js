(function() {
    tinymce.PluginManager.add('pushortcodes_element', function( editor )
    {
        editor.addButton('pushortcodes_element', {
            type: 'menubutton',
            text: 'Elements',
            menu: [
                {
                    text: 'Video', onclick: function() {
                        editor.insertContent('[vid site="youtube" id="43sYSMHYf-Q" w="853" h="480"]<br/><br/><br/>');
                    }
                },
                {
                    text: 'Button', onclick: function() {
                        editor.insertContent('[link to="http://minimable.fedeweb.net" width="300" pull="center" target="_blank"]Minimable[/link]<br/><br/><br/>');
                    }
                }
            ]
        });

    });
})();