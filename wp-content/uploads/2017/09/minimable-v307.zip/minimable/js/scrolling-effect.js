var ismobile=navigator.userAgent.match(/(iPad)|(iPhone)|(iPod)|(android)|(webOS)/i);
if( (!ismobile)) {
	jQuery(document).ready(function($) {
		var controller = $.superscrollorama();
		if ($('#staff-desc').length) {
			controller.addTween('#staff-desc',
			TweenMax.from( $('#staff-desc'), .5, {
				css:{left:-1700},
				onComplete: function() {
					$('#staff-desc').addClass('left-auto');
				}
			}));
		}
		if ($('#staff-team').length) {
			controller.addTween('#staff-team',
			TweenMax.from( $('#staff-team'), .5, {
				css:{right:-1700},
				onComplete: function() {
					$('#staff-team').addClass('right-auto');
				}
			}));
		}
		$('.gallery').each(function() {
			var element = $(this);
			controller.addTween(element,
			TweenMax.from( $(this), .5, {
				css:{opacity:0},
				onComplete: function() {
					element.addClass('visible');
				}
			}));
		});
		$('.portfolio-container').each(function() {
			var element = $(this);
			controller.addTween(element,
			TweenMax.from( $(this), .5, {
				css:{opacity:0},
				onComplete: function() {
					element.addClass('visible');
				}
			}));
		});
		if ($('#find-us').length) {
			controller.addTween('#find-us',
			TweenMax.from( $('#find-us'), .5, {
				css:{top:20},
				onComplete: function() {
					$('#find-us').addClass('top-auto');
				}
			}));
		}
		if ($('#contact-info').length) {
			controller.addTween('#contact-info',
			TweenMax.from( $('#contact-info'), .5, {
				css:{top:20},
				onComplete: function() {
					$('#contact-info').addClass('top-auto');
				}
			}));
		}
		$('.full-width-container').each(function() {
			var element = $(this);
			controller.addTween(element,
			TweenMax.from( $(this), .5, {
				css:{opacity:0},
				onComplete: function() {
					element.addClass('visible');
				}
			}));
		});

	});
}