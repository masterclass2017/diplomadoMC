jQuery(document).ready(function($) {

  var heightLoader = window.heightPreload;

	$('.section-page').last().addClass('last-section');

	$(".swipebox, .gallery-icon a").swipebox( {
    hideBarsDelay : 0,
    useSVG : false
  });
  $("div.gallery a img").each(function() {
    var $this = jQuery(this);
    $this.parent().attr('title', $this.attr('alt'));
  });

    $(".nav-tabs li").click(function() {
      $('.nav-tabs li').removeClass("active");
      $(this).addClass("active");
      $(".tab-pane").hide();

      var activeTab = $(this).find("a").attr("href");
      $(activeTab).fadeIn();
      return false;
    });
  var ismobile=navigator.userAgent.match(/(iPhone)|(iPod)|(android)|(webOS)/i);
  if( (!ismobile )) {
    $('.full-home').css('height', window.innerHeight+'px');
    $(window).resize(function() {
      $('.full-home').css('height', window.innerHeight+'px');
    });
  }
  if (!$('html').hasClass('ie8')) {
    $("body").queryLoader2({
        percentage        : true,
        barHeight         : heightLoader,
        minimumTime       : 1000,
        barColor          : '#000',
        backgroundColor   : '#fff',
        onComplete: function() {
          if($('#menu-top').length) {
            TweenMax.to( $('#menu-top'), 1, {css:{top:0,opacity:1}});
          }
        }
    });
  }
  jQuery(window).load(function(){
      $('#prepage').fadeOut().remove();
  });
  /* Particles Effect */

  if ($('#particles-js').length) {
    particlesJS("particles-js", {
      "particles": {
        "number": {
          "value": 50,
          "density": {
            "enable": true,
            "value_area": 1000
          }
        },
        "color": {
          "value": "#000000"
        },
        "shape": {
          "type": "circle",
          "stroke": {
            "width": 0,
            "color": "#000000"
          },
          "polygon": {
            "nb_sides": 5
          }
        },
        "opacity": {
          "value": 0.5,
          "random": false,
          "anim": {
            "enable": false,
            "speed": 1,
            "opacity_min": 0.1,
            "sync": false
          }
        },
        "size": {
          "value": 3,
          "random": true,
          "anim": {
            "enable": false,
            "speed": 10,
            "size_min": 0.1,
            "sync": false
          }
        },
        "line_linked": {
          "enable": true,
          "distance": 150,
          "color": "#000000",
          "opacity": 0.4,
          "width": 1
        },
        "move": {
          "enable": true,
          "speed": "3",
          "direction": "none",
          "random": false,
          "straight": false,
          "out_mode": "out",
          "bounce": false,
          "attract": {
            "enable": false,
            "rotateX": 600,
            "rotateY": 1200
          }
        }
      },
      "interactivity": {
        "detect_on": "canvas",
        "events": {
          "onhover": {
            "enable": false,
            "mode": "grab"
          },
          "onclick": {
            "enable": false,
            "mode": "push"
          },
          "resize": true
        },
        "modes": {
          "grab": {
            "distance": 250,
            "line_linked": {
              "opacity": 1
            }
          },
          "bubble": {
            "distance": 400,
            "size": 40,
            "duration": 2,
            "opacity": 8,
            "speed": 3
          },
          "repulse": {
            "distance": 200,
            "duration": 0.4
          },
          "push": {
            "particles_nb": 4
          },
          "remove": {
            "particles_nb": 2
          }
        }
      },
      "retina_detect": true
    });
  }

/* End Particles */

});
//navigation

var lastId,
topMenu = $(".top-nav"),
scrollDown = $(".scroll-down"),
topMenuHeight = topMenu.outerHeight()+15,
// All list items
menuItems = topMenu.find("a"),
// Anchors corresponding to menu items
scrollItems = menuItems.map(function(){
  var item = $($(this).parent().not('.custom-link,.sub-menu li').children().attr("href"));
  if (item.length) { return item; }
});
var homeSection = $('.home-section');
if(homeSection.length) {
  var id = $('.home-section').attr('id');
  $('#mini-logo a').attr("href","#"+id);
}

if ($('#menu-top').length) {
  menuItems.add(scrollDown).click(function(e){
    var href = this.hash,
    offsetTop = href === "#" ? 0 : $(href).offset().top-topMenuHeight+window.topOffset;
    $('html, body').stop().animate({
        scrollTop: offsetTop
    }, window.speed, 'easeInOutExpo');
    e.preventDefault();
  });


  $('.home-link a,#mini-logo a').add(scrollDown).click(function(e) {
    var href = this.hash,
    offsetTop = href === "#" ? 0 : $(href).offset().top-topMenuHeight+window.topOffset;
    $('html, body').stop().animate({
        scrollTop: offsetTop
    }, window.speed, 'easeInOutExpo');
    e.preventDefault();
  });
}
var homeBubble = $('#nav-home li').each(function() {
    if (!$(this).hasClass('custom-link')) {
      $('#nav-home a').add(scrollDown).click(function(e){
        var href = this.hash,
        offsetTop = href === "#" ? 0 : $(href).offset().top-topMenuHeight+window.topOffset;
        $('html, body').stop().animate({
            scrollTop: offsetTop
        }, window.speed, 'easeInOutExpo');
        e.preventDefault();
    });
  }
  return this;
});

var ismobile=navigator.userAgent.match(/(iPad)|(iPhone)|(iPod)|(android)|(webOS)/i);
if( (ismobile)) {
	$('.nav-collapse a').click(function(e) {
		$('.nav-collapse').slideUp(400, function () {
			$('.nav-collapse').css('height','0');
			$('.btn-navbar').click(function() {
				$('.nav-collapse').addClass('menu-height');
				$('.nav-collapse').slideDown(400);
			});
		});
	});
}

if ($('#menu-top').length) {
var stickyHeaderTop = 500;
// Bind to scroll
$(window).bind('scroll', function() {
   // Get container scroll position
   var fromTop = $(this).scrollTop()+topMenuHeight;

   // Get id of current scroll item
   var cur = scrollItems.map(function(){
     if ($(this).offset().top < fromTop)
       return this;
   });

   // Get the id of the current element
   cur = cur[cur.length-1];
   var id = cur && cur.length ? cur[0].id : "";

   if (lastId !== id) {
       lastId = id;
       // Set/remove active class
       menuItems
         .parent().removeClass("active")
         .end().filter("[href=#"+id+"]").parent().addClass("active");
   }
   if( jQuery(window).scrollTop() > stickyHeaderTop && $("#menu-top").hasClass('hide-menu')) {
        jQuery('.hide-menu').fadeIn();
    } else {
        jQuery('.hide-menu').fadeOut();
    }
});
}