<form method="get" id="searchform" action="<?php echo esc_url(home_url( '/' )); ?>" >
    <input type="text" value="" name="s" id="s" class="form-control" placeholder="<?php esc_html_e('Search . . . . .','starter'); ?>" autocomplete="off" />
</form>